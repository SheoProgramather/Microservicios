package cl.duoc.sevelasquez.evaluacion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EvaluacionApplication {
    public static void main(String[] args) {
        SpringApplication.run(EvaluacionApplication.class, args);
    }
}
