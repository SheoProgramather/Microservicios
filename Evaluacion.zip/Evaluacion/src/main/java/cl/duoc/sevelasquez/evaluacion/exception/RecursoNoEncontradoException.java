// RecursoNoEncontradoException.java
package cl.duoc.sevelasquez.evaluacion.exception;

public class RecursoNoEncontradoException extends RuntimeException {
    public RecursoNoEncontradoException(String mensaje) {
        super(mensaje);
    }
}
